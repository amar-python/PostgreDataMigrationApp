export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      csv_16496db839a004a4: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          col_101_7: number | null
          col_20_10_2025: string | null
          col_8700: number | null
          transfer_to_macquarie_chandler_commbank_app_amar_to_mac: string | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          col_101_7?: number | null
          col_20_10_2025?: string | null
          col_8700?: number | null
          transfer_to_macquarie_chandler_commbank_app_amar_to_mac?:
            | string
            | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          col_101_7?: number | null
          col_20_10_2025?: string | null
          col_8700?: number | null
          transfer_to_macquarie_chandler_commbank_app_amar_to_mac?:
            | string
            | null
        }
        Relationships: []
      }
      csv_16aeee83679d2043: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          account_number: number | null
          amount: number | null
          balance: number | null
          category: string | null
          column_4: boolean | null
          date: string | null
          merchant_name: string | null
          processed_on: string | null
          transaction_details: string | null
          transaction_type: string | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          account_number?: number | null
          amount?: number | null
          balance?: number | null
          category?: string | null
          column_4?: boolean | null
          date?: string | null
          merchant_name?: string | null
          processed_on?: string | null
          transaction_details?: string | null
          transaction_type?: string | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          account_number?: number | null
          amount?: number | null
          balance?: number | null
          category?: string | null
          column_4?: boolean | null
          date?: string | null
          merchant_name?: string | null
          processed_on?: string | null
          transaction_details?: string | null
          transaction_type?: string | null
        }
        Relationships: []
      }
      csv_89318c142fdf4267: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          account_number: number | null
          amount: number | null
          balance: number | null
          category: string | null
          column_4: boolean | null
          date: string | null
          merchant_name: string | null
          transaction_details: string | null
          transaction_type: string | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          account_number?: number | null
          amount?: number | null
          balance?: number | null
          category?: string | null
          column_4?: boolean | null
          date?: string | null
          merchant_name?: string | null
          transaction_details?: string | null
          transaction_type?: string | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          account_number?: number | null
          amount?: number | null
          balance?: number | null
          category?: string | null
          column_4?: boolean | null
          date?: string | null
          merchant_name?: string | null
          transaction_details?: string | null
          transaction_type?: string | null
        }
        Relationships: []
      }
      csv_9ba45e91b1d8d822: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          author: string | null
          conversation: string | null
          message: string | null
          time: string | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          author?: string | null
          conversation?: string | null
          message?: string | null
          time?: string | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          author?: string | null
          conversation?: string | null
          message?: string | null
          time?: string | null
        }
        Relationships: []
      }
      csv_bb5ce26e0e7ab676: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          transaction_summary: string | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          transaction_summary?: string | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          transaction_summary?: string | null
        }
        Relationships: []
      }
      csv_c9ea4a00c547a499: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          account_number: number | null
          amount: number | null
          balance: number | null
          category: string | null
          column_4: boolean | null
          date: string | null
          merchant_name: string | null
          processed_on: string | null
          transaction_details: string | null
          transaction_type: string | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          account_number?: number | null
          amount?: number | null
          balance?: number | null
          category?: string | null
          column_4?: boolean | null
          date?: string | null
          merchant_name?: string | null
          processed_on?: string | null
          transaction_details?: string | null
          transaction_type?: string | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          account_number?: number | null
          amount?: number | null
          balance?: number | null
          category?: string | null
          column_4?: boolean | null
          date?: string | null
          merchant_name?: string | null
          processed_on?: string | null
          transaction_details?: string | null
          transaction_type?: string | null
        }
        Relationships: []
      }
      csv_e2e_ambig_1784525414_5658: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          i: number | null
          idx: string | null
          name: string | null
          s: number | null
          t: string | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          i?: number | null
          idx?: string | null
          name?: string | null
          s?: number | null
          t?: string | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          i?: number | null
          idx?: string | null
          name?: string | null
          s?: number | null
          t?: string | null
        }
        Relationships: []
      }
      csv_e2e_plain: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          amount: number | null
          id: number | null
          name: string | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          amount?: number | null
          id?: number | null
          name?: string | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          amount?: number | null
          id?: number | null
          name?: string | null
        }
        Relationships: []
      }
      csv_e2e_plain_1784525414_5658: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          amount: number | null
          id: number | null
          name: string | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          amount?: number | null
          id?: number | null
          name?: string | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          amount?: number | null
          id?: number | null
          name?: string | null
        }
        Relationships: []
      }
      csv_e2e_uni_1784525414_5658: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          col_1: string | null
          col_2: string | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          col_1?: string | null
          col_2?: string | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          col_1?: string | null
          col_2?: string | null
        }
        Relationships: []
      }
      csv_files: {
        Row: {
          column_names: string[]
          created_at: string
          file_hash: string
          file_name: string
          id: string
          owner_id: string | null
          row_count: number
          table_name: string
        }
        Insert: {
          column_names?: string[]
          created_at?: string
          file_hash: string
          file_name: string
          id?: string
          owner_id?: string | null
          row_count?: number
          table_name: string
        }
        Update: {
          column_names?: string[]
          created_at?: string
          file_hash?: string
          file_name?: string
          id?: string
          owner_id?: string | null
          row_count?: number
          table_name?: string
        }
        Relationships: []
      }
      csv_testambig123: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          i: number | null
          name: string | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          i?: number | null
          name?: string | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          i?: number | null
          name?: string | null
        }
        Relationships: []
      }
      csv_teststest: {
        Row: {
          _created_at: string
          _id: number
          _row_hash: string
          name: string | null
          s: number | null
        }
        Insert: {
          _created_at?: string
          _id?: number
          _row_hash: string
          name?: string | null
          s?: number | null
        }
        Update: {
          _created_at?: string
          _id?: number
          _row_hash?: string
          name?: string | null
          s?: number | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      create_csv_table: {
        Args: { p_columns: string[]; p_table_name: string; p_types: string[] }
        Returns: undefined
      }
      drop_csv_table: { Args: { p_table_name: string }; Returns: undefined }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
