import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createHash } from "crypto";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";


// Minimal CSV parser that handles quoted fields, escaped quotes ("") and
// newlines inside quoted values. Returns rows as arrays of strings.
function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let field = "";
  let row: string[] = [];
  let inQuotes = false;
  let i = 0;
  const src = text.replace(/^\uFEFF/, "");

  while (i < src.length) {
    const ch = src[i];
    if (inQuotes) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          field += '"';
          i += 2;
          continue;
        }
        inQuotes = false;
        i++;
        continue;
      }
      field += ch;
      i++;
      continue;
    }
    if (ch === '"') {
      inQuotes = true;
      i++;
      continue;
    }
    if (ch === ",") {
      row.push(field);
      field = "";
      i++;
      continue;
    }
    if (ch === "\r") {
      i++;
      continue;
    }
    if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
      i++;
      continue;
    }
    field += ch;
    i++;
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  while (rows.length && rows[rows.length - 1].every((c) => c === "")) rows.pop();
  return rows;
}

function sanitizeColumns(headers: string[]): string[] {
  const reserved = new Set(["_id", "_row_hash", "_created_at"]);
  const seen = new Map<string, number>();
  return headers.map((h, idx) => {
    let base = (h || `column_${idx + 1}`)
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9_]+/g, "_")
      .replace(/^_+|_+$/g, "");
    if (!base) base = `column_${idx + 1}`;
    if (/^[0-9]/.test(base)) base = `col_${base}`;
    if (reserved.has(base)) base = `${base}_col`;
    if (base.length > 55) base = base.slice(0, 55);

    let name = base;
    const count = seen.get(base) ?? 0;
    if (count > 0) name = `${base}_${count + 1}`;
    seen.set(base, count + 1);
    return name;
  });
}

export type ColumnType =
  | "int8"
  | "numeric"
  | "date"
  | "timestamptz"
  | "boolean"
  | "text";

const ALLOWED_TYPES: ColumnType[] = [
  "int8",
  "numeric",
  "date",
  "timestamptz",
  "boolean",
  "text",
];

function castValue(
  raw: string,
  type: ColumnType,
): { ok: true; value: string | number | boolean | null } | { ok: false; reason: string } {
  const v = raw?.trim() ?? "";
  if (v === "") return { ok: true, value: null };
  switch (type) {
    case "int8": {
      if (!/^-?\d+$/.test(v)) return { ok: false, reason: `"${raw}" is not a whole number` };
      return { ok: true, value: v };
    }
    case "numeric": {
      if (!/^-?\d+(\.\d+)?$/.test(v)) return { ok: false, reason: `"${raw}" is not a number` };
      return { ok: true, value: v };
    }
    case "boolean": {
      const lower = v.toLowerCase();
      if (["true", "t", "yes", "y", "1"].includes(lower)) return { ok: true, value: true };
      if (["false", "f", "no", "n", "0"].includes(lower)) return { ok: true, value: false };
      return { ok: false, reason: `"${raw}" is not true/false` };
    }
    case "date": {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return { ok: false, reason: `"${raw}" is not a YYYY-MM-DD date` };
      const d = new Date(v);
      if (isNaN(d.getTime())) return { ok: false, reason: `"${raw}" is not a valid date` };
      return { ok: true, value: v };
    }
    case "timestamptz": {
      const d = new Date(v);
      if (isNaN(d.getTime())) return { ok: false, reason: `"${raw}" is not a valid timestamp` };
      return { ok: true, value: d.toISOString() };
    }
    case "text":
    default:
      return { ok: true, value: raw };
  }
}

const UploadInput = z.object({
  fileName: z.string().min(1).max(255),
  content: z.string().min(1),
  types: z.array(z.enum(["int8", "numeric", "date", "timestamptz", "boolean", "text"])).optional(),
  overwrite: z.boolean().optional(),
});

export type RowError = {
  rowNumber: number; // 1-based data row number (excluding header)
  column?: string;
  value?: string;
  reason: string;
};

export type ProcessingLog = {
  ts: number;
  step:
    | "receive"
    | "hash"
    | "duplicate_check"
    | "parse"
    | "validate_columns"
    | "create_table"
    | "cast_rows"
    | "insert"
    | "register"
    | "overwrite"
    | "done"
    | "error";
  level: "info" | "warn" | "error";
  message: string;
  count?: number;
  sql?: string;
};

export type InvalidReason = "empty" | "header_only" | "no_columns";

export type UploadResult =
  | {
      status: "ok";
      fileId: string;
      tableName: string;
      totalRows: number;
      insertedRows: number;
      duplicateRowsSkipped: number;
      failedRows: number;
      columns: string[];
      types: ColumnType[];
      rowErrors: RowError[];
      logs: ProcessingLog[];
      overwritten?: boolean;
      replacedFileName?: string;
    }
  | {
      status: "duplicate_file";
      reason: "content" | "name";
      existingFileName: string;
      tableName: string;
      existingRowCount?: number;
      logs: ProcessingLog[];
    }
  | {
      status: "invalid_structure";
      reason: InvalidReason;
      message: string;
      logs: ProcessingLog[];
    }
  | { status: "error"; message: string; rowErrors?: RowError[]; logs: ProcessingLog[] };


export const uploadCsv = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => UploadInput.parse(input))
  .handler(async ({ data, context }): Promise<UploadResult> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const ownerId = context.userId;


    const logs: ProcessingLog[] = [];
    const log = (
      step: ProcessingLog["step"],
      message: string,
      opts: { level?: ProcessingLog["level"]; count?: number; sql?: string } = {},
    ) => {
      logs.push({
        ts: Date.now(),
        step,
        level: opts.level ?? "info",
        message,
        count: opts.count,
        sql: opts.sql,
      });
    };

    log("receive", `Received "${data.fileName}" (${data.content.length} chars)`);

    const fileHash = createHash("sha256").update(data.content).digest("hex");
    log("hash", `Computed content hash ${fileHash.slice(0, 12)}…`);

    // Parse first so we can distinguish empty / header-only files up front.
    const rows = parseCsv(data.content);
    log("parse", `Parsed ${rows.length} raw rows (including header)`, { count: rows.length });
    if (rows.length === 0) {
      log("parse", "File contains no rows", { level: "warn" });
      return {
        status: "invalid_structure",
        reason: "empty",
        message: "This CSV is empty — no header row and no data rows were detected.",
        logs,
      };
    }
    if (rows.length === 1) {
      log("parse", "File contains only a header row", { level: "warn" });
      return {
        status: "invalid_structure",
        reason: "header_only",
        message:
          "This CSV has a header row but no data rows. Add at least one data row and try again.",
        logs,
      };
    }
    if (rows[0].every((c) => (c ?? "").trim() === "")) {
      log("parse", "Header row is blank", { level: "warn" });
      return {
        status: "invalid_structure",
        reason: "no_columns",
        message: "This CSV's first row is blank, so we can't detect any column headers.",
        logs,
      };
    }

    // Duplicate FILENAME check
    log("duplicate_check", "Checking existing filename", {
      sql: "select file_name, table_name, file_hash, row_count from csv_files where file_name = $1",
    });
    const { data: nameMatch } = await supabaseAdmin
      .from("csv_files")
      .select("id, file_name, table_name, file_hash, row_count")
      .eq("file_name", data.fileName)
      .eq("owner_id", ownerId)
      .maybeSingle();

    let overwroteFileName: string | undefined;

    if (nameMatch) {
      if (!data.overwrite) {
        log("duplicate_check", `Filename already exists (${nameMatch.file_name})`, { level: "warn" });
        return {
          status: "duplicate_file",
          reason: nameMatch.file_hash === fileHash ? "content" : "name",
          existingFileName: nameMatch.file_name,
          tableName: nameMatch.table_name,
          existingRowCount: nameMatch.row_count ?? 0,
          logs,
        };
      }
      log("overwrite", `Overwriting previous upload "${nameMatch.file_name}"`, { level: "warn" });
      await supabaseAdmin.rpc("drop_csv_table", { p_table_name: nameMatch.table_name });
      await supabaseAdmin.from("csv_files").delete().eq("id", nameMatch.id);
      overwroteFileName = nameMatch.file_name;
    }

    // Duplicate CONTENT check
    log("duplicate_check", "Checking existing content hash", {
      sql: "select file_name, table_name from csv_files where file_hash = $1",
    });
    const { data: existing } = await supabaseAdmin
      .from("csv_files")
      .select("id, file_name, table_name, row_count")
      .eq("file_hash", fileHash)
      .eq("owner_id", ownerId)
      .maybeSingle();

    if (existing) {
      if (!data.overwrite) {
        log("duplicate_check", `Content matches existing file (${existing.file_name})`, { level: "warn" });
        return {
          status: "duplicate_file",
          reason: "content",
          existingFileName: existing.file_name,
          tableName: existing.table_name,
          existingRowCount: existing.row_count ?? 0,
          logs,
        };
      }
      log("overwrite", `Overwriting previous content match "${existing.file_name}"`, { level: "warn" });
      await supabaseAdmin.rpc("drop_csv_table", { p_table_name: existing.table_name });
      await supabaseAdmin.from("csv_files").delete().eq("id", existing.id);
      overwroteFileName = overwroteFileName ?? existing.file_name;
    }

    // Stricter server-side column validation (defense in depth on top of client sanitizer).
    const columns = sanitizeColumns(rows[0]);
    if (columns.length === 0) {
      log("error", "No usable column names in header", { level: "error" });
      return { status: "error", message: "No columns found in the CSV header.", logs };
    }
    const dupeIdx = columns.findIndex((c, i) => columns.indexOf(c) !== i);
    if (dupeIdx !== -1) {
      const msg = `Duplicate sanitized column name "${columns[dupeIdx]}" — rename headers in the CSV.`;
      log("validate_columns", msg, { level: "error" });
      return { status: "error", message: msg, logs };
    }
    if (columns.some((c) => !/^[a-z_][a-z0-9_]{0,62}$/.test(c))) {
      log("validate_columns", "One or more sanitized column names are still invalid", { level: "error" });
      return { status: "error", message: "Column headers could not be converted to safe identifiers.", logs };
    }
    log("validate_columns", `Validated ${columns.length} columns`, { count: columns.length });

    // Types: use client-supplied inference or default to text.
    let types: ColumnType[];
    if (data.types && data.types.length === columns.length) {
      types = data.types as ColumnType[];
    } else {
      types = columns.map(() => "text" as ColumnType);
    }
    // Whitelist safety
    if (types.some((t) => !ALLOWED_TYPES.includes(t))) {
      log("error", "Unsupported column type provided", { level: "error" });
      return { status: "error", message: "Unsupported column type provided.", logs };
    }

    const ownerHash = createHash("sha256").update(`${ownerId}:${fileHash}`).digest("hex");
    const tableName = `csv_${ownerHash.slice(0, 16)}`;
    log("create_table", `create_csv_table(${tableName}, [${columns.length} cols])`, {
      sql: `select create_csv_table('${tableName}', ARRAY[...], ARRAY[...])`,
    });

    const { error: createErr } = await supabaseAdmin.rpc("create_csv_table", {
      p_table_name: tableName,
      p_columns: columns,
      p_types: types,
    });
    if (createErr && !/already exists/i.test(createErr.message)) {
      log("create_table", createErr.message, { level: "error" });
      return { status: "error", message: `Could not create table: ${createErr.message}`, logs };
    }
    log("create_table", `Table ${tableName} ready`);

    const dataRows = rows.slice(1);
    const seen = new Set<string>();
    const toInsert: Record<string, unknown>[] = [];
    const rowErrors: RowError[] = [];
    let duplicates = 0;

    for (let r = 0; r < dataRows.length; r++) {
      const raw = dataRows[r];
      const rowNumber = r + 1;
      const obj: Record<string, unknown> = {};
      let rowFailed = false;
      const rawJoined: string[] = [];

      for (let c = 0; c < columns.length; c++) {
        const cellRaw = raw[c] ?? "";
        rawJoined.push(cellRaw);
        const cast = castValue(cellRaw, types[c]);
        if (!cast.ok) {
          rowErrors.push({
            rowNumber,
            column: columns[c],
            value: cellRaw,
            reason: cast.reason,
          });
          rowFailed = true;
          break;
        }
        obj[columns[c]] = cast.value;
      }

      if (rowFailed) continue;

      const rowHash = createHash("sha256")
        .update(rawJoined.join("\u0001"))
        .digest("hex");
      if (seen.has(rowHash)) {
        duplicates++;
        continue;
      }
      seen.add(rowHash);
      toInsert.push({ ...obj, _row_hash: rowHash });
    }
    log("cast_rows", `Cast ${dataRows.length} rows → ${toInsert.length} valid, ${rowErrors.length} errors, ${duplicates} in-file duplicates`, {
      count: toInsert.length,
      level: rowErrors.length ? "warn" : "info",
    });

    const chunkSize = 500;
    let inserted = 0;
    for (let i = 0; i < toInsert.length; i += chunkSize) {
      const chunk = toInsert.slice(i, i + chunkSize);
      log("insert", `Upserting chunk ${i / chunkSize + 1} (${chunk.length} rows)`, {
        sql: `insert into ${tableName} (...) values (...) on conflict (_row_hash) do nothing`,
      });
      const { error, count } = await ((supabaseAdmin as unknown as {
        from: (t: string) => {
          upsert: (
            v: unknown,
            o: { onConflict: string; ignoreDuplicates: boolean; count: "exact" },
          ) => Promise<{ error: { message: string } | null; count: number | null }>;
        };
      }).from(tableName))
        .upsert(chunk, { onConflict: "_row_hash", ignoreDuplicates: true, count: "exact" });
      if (error) {
        log("insert", error.message, { level: "error" });
        return { status: "error", message: `Insert failed: ${error.message}`, rowErrors, logs };
      }
      inserted += count ?? chunk.length;
    }
    log("insert", `Inserted ${inserted} rows`, { count: inserted });

    log("register", "Registering file in csv_files", {
      sql: "insert into csv_files (file_name, file_hash, table_name, row_count, column_names) values (...)",
    });
    const { data: fileRow, error: regErr } = await supabaseAdmin
      .from("csv_files")
      .insert({
        file_name: data.fileName,
        file_hash: fileHash,
        table_name: tableName,
        row_count: inserted,
        column_names: columns,
        owner_id: ownerId,
      })
      .select("id")
      .single();


    if (regErr || !fileRow) {
      log("register", regErr?.message ?? "unknown error", { level: "error" });
      return { status: "error", message: `Could not register file: ${regErr?.message ?? "unknown"}`, rowErrors, logs };
    }

    log("done", `Import complete for ${data.fileName}`);
    return {
      status: "ok",
      fileId: fileRow.id,
      tableName,
      totalRows: dataRows.length,
      insertedRows: inserted,
      duplicateRowsSkipped: duplicates,
      failedRows: rowErrors.length,
      columns,
      types,
      rowErrors,
      logs,
      overwritten: !!overwroteFileName,
      replacedFileName: overwroteFileName,
    };
  });



export type CsvFileSummary = {
  id: string;
  file_name: string;
  table_name: string;
  row_count: number;
  column_names: string[];
  created_at: string;
};

export const listCsvFiles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<CsvFileSummary[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("csv_files")
      .select("id, file_name, table_name, row_count, column_names, created_at")
      .eq("owner_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []) as CsvFileSummary[];
  });

const PreviewInput = z.object({
  tableName: z.string().regex(/^csv_[a-z0-9_]{1,60}$/),
  limit: z.number().int().min(1).max(200).default(50),
});

export const previewCsvTable = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => PreviewInput.parse(input))
  .handler(async ({ data, context }): Promise<{ rows: Record<string, string | number | boolean | null>[] }> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Verify the caller owns this table before returning any data.
    const { data: fileRow, error: ownerErr } = await supabaseAdmin
      .from("csv_files")
      .select("id")
      .eq("table_name", data.tableName)
      .eq("owner_id", context.userId)
      .maybeSingle();
    if (ownerErr) throw new Error(ownerErr.message);
    if (!fileRow) throw new Error("Not found");

    const { data: rows, error } = await ((supabaseAdmin as unknown as {
      from: (t: string) => {
        select: (s: string) => {
          order: (
            c: string,
            o: { ascending: boolean },
          ) => {
            limit: (n: number) => Promise<{
              data: Record<string, string | number | boolean | null>[] | null;
              error: { message: string } | null;
            }>;
          };
        };
      };
    }).from(data.tableName))
      .select("*")
      .order("_id", { ascending: true })
      .limit(data.limit);
    if (error) throw new Error(error.message);
    return { rows: (rows ?? []) as Record<string, string | number | boolean | null>[] };
  });

